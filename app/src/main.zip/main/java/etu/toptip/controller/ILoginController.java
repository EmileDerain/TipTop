package etu.toptip.controller;

public interface ILoginController {
    int OnLogin(String email,String Password);
}
