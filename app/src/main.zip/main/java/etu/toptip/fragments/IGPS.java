package etu.toptip.fragments;

public interface IGPS {
    int REQUEST_CODE = 400;
    void moveCamera();
}
