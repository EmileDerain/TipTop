package etu.toptip.fragments;

public interface ICameraPermission {
    int REQUEST_CAMERA = 100;
}
