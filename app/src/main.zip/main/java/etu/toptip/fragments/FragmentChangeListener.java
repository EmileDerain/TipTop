package etu.toptip.fragments;

import androidx.fragment.app.Fragment;

public interface FragmentChangeListener
{
    public void replaceFragment(Fragment fragment);
}
