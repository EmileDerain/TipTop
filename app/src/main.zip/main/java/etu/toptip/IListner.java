package etu.toptip;

import etu.toptip.model.Place;

public interface IListner {
    public void OnClickPlace(Place place);
}
